using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LogSpawner : MonoBehaviour, ISpawner
{
    public GameObject LogPrefab;
    public float SpawnCooltime;
    public float MinSpawnCooltime = 0.5f;
    public float MaxSpawnCooltime = 3f;
    private void Start()
    {
        StartCoroutine(Spawn());
        SpawnCooltime = Random.Range(MinSpawnCooltime, MaxSpawnCooltime);
    }

    public IEnumerator Spawn()
    {
        while (true)
        {
            GameObject log = Instantiate(LogPrefab, gameObject.transform.position, gameObject.transform.rotation);
            log.transform.SetParent(transform);
            
            yield return new WaitForSeconds(SpawnCooltime);
        }
    }
}
